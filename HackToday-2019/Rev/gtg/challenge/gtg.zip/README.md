# gtg
Friska leave the group. (✖╭╮✖).
.
.
.
Eits. Tunggu dulu, sebelum pergi, Friska meniggalakan pesan ini
```
Ww6b6IRPm28BAnwpymvaqMgBGmm0YBppNtVO7jrayur/Wq/e
```
Bisakah kamu mengartikan pesan tersebut?


<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "hibikicp";

    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
?>
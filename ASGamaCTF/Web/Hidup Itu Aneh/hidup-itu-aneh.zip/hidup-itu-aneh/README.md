# gamactf2-web1
Hint : google for Max Caufield Superpower
